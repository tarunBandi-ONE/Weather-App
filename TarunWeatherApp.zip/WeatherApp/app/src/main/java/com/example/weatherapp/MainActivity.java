package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    String zip = "08852";
    final String key = "99ce42933a34f202d59baad28fa291ea";
    URL link , link2;
    URLConnection urlConnection,urlConnection2;
    InputStream inputStream,inputStream2;
    BufferedReader bufferedReader,bufferedReader2;
    String JsonDATA,JsonDATA2;
    TextView data,date,low1,low2,low3,low4,low5,high1,high2,high3,high4,high5,date1,date2,date3,date4,date5,weather,quotes;
    String mydata ="";
    String temperature;
    String singleparsed = "";
    EditText editText;
    Button weatherbutton;
    String updateString;
    String temp;
    String updatedAtText;
    ImageView image,image2,image3,image4,image5,image6;
    JSONArray JA,J2;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);
        data = findViewById(R.id.data);
        weatherbutton = findViewById(R.id.weather_button);
        quotes = findViewById(R.id.quote2);
        editText = findViewById(R.id.editText);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                temp = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {

                    zip = temp;


            }
        });
        weatherbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                WeatherApi E = new WeatherApi();
                E.execute();
           }
        });

    }
    public class WeatherApi extends AsyncTask<String, Void, String>
    {
        @Override
        protected String doInBackground(String... strings) {
            try
            {
                link = new URL("https://api.openweathermap.org/data/2.5/forecast?zip=" + zip + "&appid=" + key+"&units=imperial");
                urlConnection = link.openConnection();
                inputStream = urlConnection.getInputStream();
                bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                JsonDATA = bufferedReader.readLine();
                link2 = new URL("https://api.openweathermap.org/data/2.5/weather?zip=" + zip + ",us&appid=" + key+"&units=imperial");
                urlConnection2 = link2.openConnection();
                inputStream2 = urlConnection2.getInputStream();
                bufferedReader2 = new BufferedReader(new InputStreamReader(inputStream2));
                JsonDATA2 = bufferedReader2.readLine();
                JSONObject jsonObject = new JSONObject(JsonDATA2);
                JSONArray weather = jsonObject.getJSONArray("weather");
                JSONObject main = jsonObject.getJSONObject("main");
                temperature = main.getString("temp")+" °F";
                long updatedAt = jsonObject.getLong("dt");
                 updatedAtText = "Updated on: " + new SimpleDateFormat("MM/dd/yyyy ", Locale.ENGLISH).format(new Date(updatedAt * 1000));
                 JSONObject json = new JSONObject(JsonDATA);
                 JA = json.getJSONArray("list");
                 mydata = weather.getJSONObject(0).getString("icon");
                 Log.d("please bruh",mydata);



            }
            catch (Exception e){}
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            setContentView(R.layout.activity_main);
            low1 = findViewById(R.id.low1);
            low2 = findViewById(R.id.low2);
            low3 = findViewById(R.id.low3);
            low4 = findViewById(R.id.low4);
            low5 = findViewById(R.id.low5);
            
            high1 = findViewById(R.id.high1);
            high2 = findViewById(R.id.high2);
            high3 = findViewById(R.id.high3);
            high4 = findViewById(R.id.high4);
            high5 = findViewById(R.id.high5);

            date1 = findViewById(R.id.date1);
            date2 = findViewById(R.id.date2);
            date3 = findViewById(R.id.date3);
            date4 = findViewById(R.id.date4);
            date5 = findViewById(R.id.date5);
            
            data = findViewById(R.id.data);
            date = findViewById(R.id.date);

            image = findViewById(R.id.image2);
            image2 = findViewById(R.id.image3);
            image3 = findViewById(R.id.image4);
            image4 = findViewById(R.id.image5);
            image5 = findViewById(R.id.image6);

            data.setText(temperature);
            date.setText(updatedAtText);
            try {
                date1.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(new Date(JA.getJSONObject(0).getLong("dt") * 1000)));
                date2.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(new Date(JA.getJSONObject(1).getLong("dt") * 1000)));
                date3.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(new Date(JA.getJSONObject(2).getLong("dt") * 1000)));
                date4.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(new Date(JA.getJSONObject(3).getLong("dt") * 1000)));
                date5.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(new Date(JA.getJSONObject(4).getLong("dt") * 1000)));

                low1.setText("Low:"+JA.getJSONObject(0).getJSONObject("main").getString("temp_min")+"°");
                low2.setText("Low:"+JA.getJSONObject(1).getJSONObject("main").getString("temp_min")+"°");
                low3.setText("Low:"+JA.getJSONObject(2).getJSONObject("main").getString("temp_min")+"°");
                low4.setText("Low:"+JA.getJSONObject(3).getJSONObject("main").getString("temp_min")+"°");
                low5.setText("Low:"+JA.getJSONObject(4).getJSONObject("main").getString("temp_min")+"°");
                
                high1.setText("High:"+JA.getJSONObject(0).getJSONObject("main").getString("temp_max")+"°");
                high2.setText("High:"+JA.getJSONObject(1).getJSONObject("main").getString("temp_max")+"°");
                high3.setText("High:"+JA.getJSONObject(2).getJSONObject("main").getString("temp_max")+"°");
                high4.setText("High:"+JA.getJSONObject(3).getJSONObject("main").getString("temp_max")+"°");
                high5.setText("High:"+JA.getJSONObject(4).getJSONObject("main").getString("temp_max")+"°");
                String icon = JA.getJSONObject(0).getJSONArray("weather").getJSONObject(0).getString("icon");
                Picasso.get().load("http://openweathermap.org/img/wn/"+icon+"@2x.png").into(image);
                icon = JA.getJSONObject(1).getJSONArray("weather").getJSONObject(0).getString("icon");
                Picasso.get().load("http://openweathermap.org/img/wn/"+icon+"@2x.png").into(image2);
                icon = JA.getJSONObject(2).getJSONArray("weather").getJSONObject(0).getString("icon");
                Picasso.get().load("http://openweathermap.org/img/wn/"+icon+"@2x.png").into(image3);
                icon = JA.getJSONObject(3).getJSONArray("weather").getJSONObject(0).getString("icon");
                Picasso.get().load("http://openweathermap.org/img/wn/"+icon+"@2x.png").into(image4);
                icon = JA.getJSONObject(4).getJSONArray("weather").getJSONObject(0).getString("icon");
                Picasso.get().load("http://openweathermap.org/img/wn/"+icon+"@2x.png").into(image5);
                image6 = findViewById(R.id.image);
                Picasso.get().load("http://openweathermap.org/img/wn/"+mydata+"@2x.png").into(image6);
                weather = findViewById(R.id.id_weather);
                if(mydata.equals("01d")||mydata.equals("01n")) {
                    weather.setText("Clear Sky");
                    quotes.setText("“At sunrise, the blue sky paints herself with gold colors and joyfully dances to the music of a morning breeze.”");

                }
                if(mydata.equals("02d")||mydata.equals("02n")) {
                    weather.setText("Few Clouds");
                    quotes.setText("Clouds come floating into my life, no longer to carry rain or usher storm, but to add color to my sunset sky.");
                }
                if(mydata.equals("03d")||mydata.equals("03n")) {
                    weather.setText("Scattered Clouds");
                    quotes.setText("It is better to have your head in the clouds, and know where you are... than to breathe the clearer atmosphere below them, and think that you are in paradise.");
                }
                if(mydata.equals("04d")||mydata.equals("04n")) {
                    weather.setText("Broken Clouds");
                    quotes.setText("There was a star riding through clouds one night, & I said to the star, Consume me.");
                }
                if(mydata.equals("05d")||mydata.equals("05n")) {
                    weather.setText("Shower Rain");
                    quotes.setText("Predicting rain doesn't count. Building arks does.");
                }
                if(mydata.equals("06d")||mydata.equals("06n")) {
                    weather.setText("Rain");
                    quotes.setText("Some people feel the rain. Others just get wet.");

                }
                if(mydata.equals("07d")||mydata.equals("07n")) {
                    weather.setText("Thunderstorm");
                   quotes.setText("Thunderstorms are as much our friends as the sunshine.");
                }
                if(mydata.equals("08d")||mydata.equals("08n")) {
                    weather.setText("Snow");
                    quotes.setText("A snowball in the face is surely the perfect beginning to a lasting friendship.");
                }
                if(mydata.equals("09d")) {
                    weather.setText("Mist");
                    quotes.setText("Sob, heavy world Sob as you spin, Mantled in mist Remote from the happy");
                }
                if(mydata.equals("09n")) {
                    weather.setText("Mist");
                    quotes.setText("At night the fog was thick and full of light, and sometimes voices");
                }




            }
            catch(Exception e)
            {
               
            }
        }

    }
}
